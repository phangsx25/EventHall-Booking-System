#include<iostream>
#include<string>
#include<iomanip>
#include<ctime>
#include<exception>
#include<fstream>
#include<vector>


using namespace std;

class Date{
    private:
         string day, month, year;
    public: 
         Date(string d="1", string m="1", string y="2025")
         {
            day=d;
            month=m;
            year=y;
         }
         void setDate(string d, string m, string y)
         { 
            if(!isValid(d,m,y))
             throw invalid_argument("Invalid date.");
            day=d;
            month=m;
            year=y;
         }

         static bool isLeapYear(int y)
         {
            return(y%4 ==0);
         }

         static bool isValid(string d, string m, string y)
         {
            if(d==""|| m==""|| y=="" )
               return false;
            int _d=stoi(d);
            int _m=stoi(m);
            int _y=stoi(y);
            if(_y<2024 || _y>2100)
              return false;
            if(_m<1 || _m>12)
              return false;   
           //list all last date in every month
           int daysInMonth[]={31,28,31,30,31,30,31,31,30,31,30,31}; 
           if(isLeapYear(_y)) 
             daysInMonth[1]=29;
           
           if(_d<1 || _d> daysInMonth[_m-1])
            return false;
           return true;
         }
        
         string getDate() const
         {
            string d = day;
            string m = month;
           if (d.length() == 1) d = "0" + d;
           if (m.length() == 1) m = "0" + m;
           return d + "-" + m + "-" + year;
         }
         void enterDate()
         {
            cout<<"Please enter date (DD MM YYYY): ";
            cin>>day>>month>>year;
            if(!isValid(day,month,year))
            {
              throw invalid_argument("Invalid date format.");
            }
            
         }
         bool isFutureDate(time_t currentTime)const
         {
          tm* lt=localtime(&currentTime);
          int curY=1900 + lt->tm_year;
          int curM=1 + lt->tm_mon;
          int curD=lt->tm_mday;

          int _y=stoi(year);
          int _m=stoi(month);
          int _d=stoi(day);
    
          if (_y > curY)
            return true;
          if ((_y == curY)&&(_m >curM ))
            return true;
          if ((_y == curY)&&(_m == curM )&&(_d > curD))
            return true;
        return false;   
         }
         
         string getDay()const{return day;}
         string getMonth()const{return month;}
         string getYear()const{return year;}
         ~Date(){}
};

class Time{
    private:
        string hour, minute;
    public:
        Time(string h="", string m="")
        {
            hour=h;
            minute=m;
        }
        void setTime(string h, string m)
        {
            if(!isValid(h,m))
              throw invalid_argument("Invalid time");
            hour=h;
            minute=m;
        }

        static bool isValid(string h, string m)
        {
            if(h==""|| m=="")
             return false;
            int _h=stoi(h);
            int _m=stoi(m);
            return (((_h>=0) && (_h<=23) )&& ((_m>=0)&&(_m<=59)));
        }
        string getTime() const 
        {
        string h = hour;
        string m = minute;
        if (h.length() == 1) h = "0" + h;
        if (m.length() == 1) m = "0" + m;
        return h + ":" + m;
        }
        void enterTime()
        {
            cout<<"Please enter the time (HH MM): ";
            cin>>hour>>minute;
            if(!isValid(hour, minute))
              throw invalid_argument("Invalid time entered.");
        }
        int getHour()const {return stoi(hour);}
        int getMinute()const{return stoi(minute);}

        Time addMi(int miToAdd) const
        {
            int h=getHour();
            int m=getMinute();
            int total=(h*60) + m + miToAdd;
            int newH=total/60;
            int newM=total%60; 
            return Time(to_string(newH), to_string(newM));
        }

        //check time overlape or not
        static bool checkOverlape(Time a1, Time b1, Time a2, Time b2)
        {
            int a1min= a1.getHour()*60 +a1.getMinute();
            int b1min= b1.getHour()*60 +b1.getMinute();
            int a2min= a2.getHour()*60 +a2.getMinute();
            int b2min= b2.getHour()*60 +b2.getMinute();
            return !(b1min<= a2min || a1min>= b2min);
        }
        //check the time is in the range or not

        bool isTimeInRange()const
        {
          int min=getHour() *60 + getMinute();
          return ((min >= 600) && (min <= 1350));//10am=600 min 2330pm=1350min
        }

        //check time is not exceed 2330, operation time.
        bool exceedTime(int duration)const
        {
          Time end= this->addMi(duration*60);
          int totMin= (end.getHour()*60) + (end.getMinute());
          return totMin <=1410;
        }
        ~Time(){}
};
class User{
    protected:
     string name, email, phone, password;
    public:
      User(){}
      User(string n, string e , string p, string ps)
      {
         name = n;
         email = e;
         phone = p;
         password = ps;
         
      }
      void setName(string n){name=n;}
      void setEmail(string e){email=e;}
      void setPhone(string p){phone=p;}
      void setPassword(string ps){password=ps;}
      virtual void setAcc()=0;
      string getName(){return name;}
      string getEmail(){return email;}
      string getPhone(){return phone;}
      string getPassword(){return password;}

      virtual void dispDashboard()=0;

      static bool isValidEmail(const string &email)
      {
        return (email.find('@') != string::npos )&& (email.find(".com") != string::npos);
      }

      static bool isValidPhoneNo(const string &phone)
      {
        return (phone.length()==12 || phone.length()==11) && (phone[0]=='0' && phone[1]=='1' && phone[3]=='-');
      }

      static bool isValidPasswordFormat(string ps)
      {
        while (ps.length()<6)
        {
          cout<<"Password must be exactly 6 characters. Re-enter: ";
          return false;
        }
        if(ps.length()>=6)
        {
          ps=ps.substr(0,6);
        }
        return true;
      }
      
      
      bool checkLogin(string n, string ps)
      {
        return (name==n && password==ps);
      }
      virtual void updateProfile()=0;
      void dispProfile(string n, string e , string p, string ps)
      {
        cout << "\n--- Profile Information ---"<<endl;
        cout << "Name: " << name << endl;
        cout << "Email: " << email << endl;
        cout << "Phone: " << phone << endl;
        cout << "Password: " << password << endl;
      }
      virtual ~User(){}
};

class Admin :public User{
    private:
        string adminID;
        static int adminCount;
    public:
        Admin(){}
        Admin(string id, string n, string e, string p, string ps): User(n,e,p,ps)
        {
            adminID=id;
        }
        Admin(string n, string e, string p, string ps): User(n,e,p,ps)
        {
          adminID=generateAdminID();
        }
        void setID(string id){adminID=id;}

        string getID() const { return adminID; }
        string getName() const { return name; }
        string getEmail() const { return email; }
        string getPhone() const { return phone; }
        string getPassword() const { return password; }

        string generateAdminID()
        {
          adminCount++;
          string prefix="A";
          string id=to_string(adminCount);
          while(id.length()<3)
          {
            id="0"+id;
          }
          return prefix +id;
        }

    static void setAdminCount(const vector<Admin>&adminList)
    {
    ifstream in("admin.txt");
    if (in)
    {
        string line;
        getline(in, line); // skip header
        int maxID = 0;
        while (getline(in, line))
        {
            size_t pos = line.find(',');
            string id = line.substr(0, pos); // e.g. A003
            if (id.length() > 1 && id[0] == 'A')
            {
                try {
                    int num = stoi(id.substr(1));
                    if (num > maxID) maxID = num;
                } catch (...) { continue; }
            }
        }
        adminCount = maxID;
    }
    else
    {
        adminCount = 0;
    }
}

      
void loadAdmin(vector<Admin>&adminList)
{
  ifstream in("admin.txt");
           
  string line;
  getline(in, line);        
  while(getline(in,line))
  {
    size_t pos1 = line.find(',');
    string id= line.substr(0,pos1);

    size_t pos2 = line.find(',',pos1+1);
    string n= line.substr(pos1+1,pos2-pos1-1);//read name

    size_t pos3 = line.find(',',pos2+1);
    string e= line.substr(pos2+1,pos3-pos2-1);//read email

    size_t pos4 = line.find(',',pos3+1);
    string p= line.substr(pos3+1,pos4-pos3-1);//read phone number

    string ps= line.substr(pos4+1);//read phone number
    adminList.push_back(Admin(id,n,e,p,ps));
  }
  in.close();
}

void dispDashboard()
{
  cout << "\n-----Admin Menu-----" << endl;
        cout << "1. View Profile" << endl;
        cout << "2. Update Profile" << endl;
        cout << "3. Change Password" << endl;
        cout << "4. Hall Management" << endl;
        cout << "5. Booking Management" << endl;
        cout << "6. Add New Admin" << endl;
        cout << "0. Exit" << endl;
        cout << "Your Choice: ";
}
void updateProfile() override 
{  
           
  cout << "\n--- Update Admin Profile ---\n";
  cout << "Admin ID: " << adminID << endl;
  cout << "Name: "<<name<<endl;

  string newEmail;
  do{
     cout<<"Email: ";
    getline(cin,newEmail);
    if(!isValidEmail(newEmail))
    {
      cout<<"Invalid email format! Must contain '@' and '.com'"<<endl;
    }
    }while(!isValidEmail(newEmail));
   email=newEmail;

  string newPhone;
   do{
      cout<<"Phone(format: 01X-XXXXXXXX): ";
      getline(cin,newPhone);
      if(!isValidPhoneNo(newPhone))
       {
         cout<<"Invalid phone format! Must be 10 to 11 digits."<<endl;
       }
     }while(!isValidPhoneNo(newPhone));
    phone=newPhone;

    string newPassword;
    do{
        cout<<"Password (6 characters): ";
        getline(cin,newPassword);
      }while(!isValidPasswordFormat(newPassword));
      password=newPassword;
          
      }

        void setAcc() override{
           cout<<"Change password for "<<name<<endl;
          do{
          cout << "Set your password (6 character): ";
          getline(cin, password);
          }while(!User::isValidPasswordFormat(password));
           cout<<"Password updated.";
        }

        void dispProfile(){
          cout<<"Admin ID: "<<adminID<<endl;
          User::dispProfile(name,email,phone,password);
        }

        void saveAdmin(const vector<Admin>& adminList) {
            ofstream out ("admin.txt");
            out<<"Admin ID,Username,Email,Phone,Password"<<endl;
            for (const Admin& a: adminList)
            {
              out<<a.getID()<<","
                 <<a.getName()<<","
                 <<a.getEmail()<<","
                 <<a.getPhone()<<","
                 <<a.getPassword()<<endl;
            }
            out.close();
        }
  ~Admin(){}
};
int Admin::adminCount=0;

class Customer: public User{
    private: 
    string customerID;
    static int custCount;
   
   public:
        Customer(){}
        //old customer
        Customer(string id, string n, string e, string p, string ps): User(n,e,p,ps)
        {
          customerID=id;
        }
        //register account
        Customer( string n, string e, string p, string ps): User(n,e,p,ps)
        {
          customerID=generateCustomerID();
        }
        void setID(string id){customerID=id;}
        string getID() const {return customerID;}
        string getName() const { return name; }
        string getEmail() const { return email; }
        string getPhone() const { return phone; }
        string getPassword() const { return password; }

        string generateCustomerID()
        {
          custCount++;
          string prefix="C";
          string id=to_string(custCount);
          while(id.length()<3)
          {
            id="0"+id;
          }
          return prefix +id;
          
        }

    static void setCustomerCount(const vector<Customer>&custList)
    {
    ifstream in("customer.txt");
    if (in)
    {
        string line;
        getline(in, line); // skip header
        int maxID = 0;
        while (getline(in, line))
        {
            size_t pos = line.find(',');
            string id = line.substr(0, pos); // e.g. C004
            if (id.length() > 1 && id[0] == 'C')
            {
                try {
                    int num = stoi(id.substr(1));
                    if (num > maxID) 
                    maxID = num;
                } catch (...) { continue; }
            }
        }
        custCount = maxID;
    }
    else
    {
      custCount = 0;
    }
}
    
   void loadCustomer(vector<Customer>  &custList)
      {
           ifstream in("customer.txt");
           if(!in.is_open())
           {
            cout<<"Failed to open customer.txt"<<endl;
            return;
           }
           
           string line;
           getline(in,line);//skip header

           while(getline(in,line))
           {
            if(line.empty()) continue;
            size_t pos1 = line.find(',');
            string id= line.substr(0,pos1);

            size_t pos2 = line.find(',',pos1+1);
            string n= line.substr(pos1+1,pos2-pos1-1);//read name

            size_t pos3 = line.find(',',pos2+1);
            string e= line.substr(pos2+1,pos3-pos2-1);//read email

            size_t pos4 = line.find(',',pos3+1);
            string p= line.substr(pos3+1,pos4-pos3-1);//read phone number

            string ps= line.substr(pos4+1);//read phone number

            custList.push_back(Customer(id,n,e,p,ps));
           }
           in.close();
        }
        void dispDashboard()
        {
          cout << "\n-----Customer Menu-----" << endl;
          cout << "1. View Profile" << endl;
          cout << "2. Update Profile" << endl;
          cout << "3. Change Password" << endl;
          cout << "4. Book A Hall" << endl;
          cout << "5. View Booking" << endl;
          cout << "6. Cancel Booking" << endl;
          cout << "0. Logout" << endl;
          cout << "Your Choice: ";
        }
        void updateProfile() override 
        {  
           cout << "\n--- Update Customer Profile ---\n";
           cout << "Customer ID: " << customerID<<endl;
           cout << "Name: "<<name<<endl;;
           string newEmail;
           do{
            cout<<"Email: ";
            getline(cin,newEmail);
            if(!isValidEmail(newEmail))
            {
              cout<<"Invalid email format! Must contain '@' and '.com'"<<endl;
            }
           }while(!isValidEmail(newEmail));
           email=newEmail;

           string newPhone;
           do{
            cout<<"Phone(format: 01X-XXXXXXXX): ";
            getline(cin,newPhone);
            if(!isValidPhoneNo(newPhone))
            {
              cout<<"Invalid phone format! Must be 10 to 11 digits."<<endl;
            }
           }while(!isValidPhoneNo(newPhone));
           phone=newPhone;

           string newPassword;
           do{
            cout<<"Password (6 characters): ";
            getline(cin,newPassword);
            if(!isValidPasswordFormat(newPassword))
            {
              cout<<"Password must be 6 character"<<endl;
            }
           }while(!isValidPasswordFormat(newPassword));
           password=newPassword;
           
        }
        void setAcc() override
        {
           cout<<"Change password for "<<name<<endl;
          do{
          cout << "Set your password (6 character): ";
          getline(cin, password);
          }while(!User::isValidPasswordFormat(password));
           cout<<"Password updated.";
        }
        void dispProfile()
        {
          cout<<"Customer ID: "<<customerID<<endl;
          User::dispProfile(name,email,phone,password);
        }

        void saveCustomer(const vector<Customer> &custList)
        {
            ofstream out ("customer.txt");
            out<<"CustomerID,Username,Email,Phone,Password"<<endl;
            for (const Customer& c: custList)
            {
              
              out<<c.getID()<<","
                 <<c.getName()<<","
                 <<c.getEmail()<<","
                 <<c.getPhone()<<","
                 <<c.getPassword()<<endl;
          
            }
            out.close();
        }
  ~Customer(){}
};
int Customer::custCount=0;

class EventHall{
    private:
      string hallName,hallID;
      int capacity;
      double price;
      static int hallCount;
    public:
      EventHall(){}
      EventHall(string id, string hname, int c, double p)
      {
        hallName=hname;
        hallID=id; 
        capacity=c;
        price=p;
      }

      
      void setHallName(string n){hallName=n;}
      void setHallID(string id){hallID=id;}
      void setCapacity(int c){capacity=c;}
      void setPrice(double p){price=p;}

      
      string getHallID()const {return hallID;}
      string getHallName()const {return hallName;}
      int getCapacity()const {return capacity;}
      double getPrice()const {return price;}
      static int getCount() {return hallCount;}


      static void setHallCount(int count)
    {
        ifstream in("hall.txt");
        if (in)
        {
            string line;
            getline(in, line);
            int maxID = 0;
            while (getline(in, line))
            {
                size_t pos = line.find(',');
                string id = line.substr(0, pos);
                if (id.length() > 1 && id[0] == 'H')
                {
                    try
                    {
                        int num = stoi(id.substr(1));
                        maxID = max(maxID, num);
                    }
                    catch (...)
                    {
                        continue;
                    }
                    hallCount = maxID;
                }
                else
                {
                    hallCount = 0;
                }
            }
        }
    }

    static void saveHallCounter()
    {
        ofstream out("hall.txt");
        out << hallCount;
    }

    string generateHallID()
    {

        hallCount++;
        string prefix = "H";
        string id = to_string(hallCount);
        while (id.length() < 3)
        {
            id = "0" + id;
        }
        return prefix + id;
    }

    void loadHall(vector<EventHall> &hallList)
    {
        ifstream in("hall.txt");
        if (!in.is_open())
        {
            cout << "Failed to open file." << endl;
            hallCount = 0;
            return;
        }

        string line;
        getline(in, line); // skip header

        while (getline(in, line))
        {
            size_t pos1 = line.find(',');
            string id = line.substr(0, pos1);

            size_t pos2 = line.find(',', pos1 + 1);
            string n = line.substr(pos1 + 1, pos2 - pos1 - 1);

            size_t pos3 = line.find(',', pos2 + 1);
            string c = line.substr(pos2 + 1, pos3 - pos2 - 1);

            string p = line.substr(pos3 + 1);

            try
            {
                int cap = stoi(c);
                double price = stod(p);
                hallList.push_back(EventHall(id, n, cap, price));
            }
            catch (...)
            {
                cout << "Error" << line << endl;
                continue;
            }
        }
        hallCount = hallList.size();
        in.close();
    }

    void setHallInfo()
    {

        cout << "Hall name: ";
        getline(cin, hallName);
        cout << "Hall capacity: ";
        cin >> capacity;
        cout << "Hall price (per hour): ";
        cin >> price;
        cin.ignore();
    }

    void updateHallInfo()
    {
        cout<<"Hall ID: ";
        getline(cin,hallID);
        cout<<"Hall name: ";
        getline(cin,hallName);
        cout<<"Hall capacity: ";
        cin>>capacity;
        cout<<"Hall price (per hour): ";
        cin>>price;
        cin.ignore();
    }

    void displayHall()
    {
        cout << left << setw(10) << hallID
             << setw(20) << hallName
             << setw(20) << capacity
             << setw(10) << fixed << setprecision(2) << price << endl;
    }
    void saveHalls(const vector<EventHall> &hallList)
    {
        ofstream out("hall.txt");
        if (!out.is_open())
        {
            cout << "Failed to open hall.txt";
            return;
        }
        out << "Hall ID,Hall Name,Capacity,Price" << endl;
        for (const EventHall &h : hallList)
        {
            out << h.getHallID() << ","
                << h.getHallName() << ","
                << h.getCapacity() << ","
                << fixed << setprecision(2) << h.getPrice() << endl;
        }
        out.close();
    }
  ~EventHall(){}
};
int EventHall::hallCount = 0;
class Invoice{
    private:
       int paymentStatus;
       double amount;
       string invoiceID; 
    public:
       Invoice ()
       {
        amount=0.0;
        invoiceID="";
       }
       void setAmount(double a){amount=a;}
       void setPaymentStatus(int ps){paymentStatus=ps;}
       void generateInvoice(string bookingID, double a)   
       {
        string numPart = bookingID.substr(1); //remove 'B'
        invoiceID = "INV" + numPart;
        amount = a;
       }
       string getPaymentStatus() const 
       {
        if (paymentStatus == 1) return "Paid";
        if (paymentStatus == -1) return "Unsuccessful";
        return "Pending";
       }
       void printInvoice()const
       {
         cout<<"-----Invoice Details-----"<<endl
             <<"Invoice id: "<<invoiceID<<endl 
             <<"Total: RM "<<fixed<<setprecision(2)<<amount<<endl
             <<"Status: Pending (please confirm with Admin)"<<endl;
        }  
       double getAmount()const {return amount;}
       string getInvoiceID()const {return invoiceID;}
  ~Invoice(){}
};
class Booking{
    private:
         static int bookingCount;
         string bookingID;
         int duration;
         string status;

         Customer *customer;
         EventHall *hall;
         Invoice invoice;
         Date date;
         Time time;
         
    public:
        Booking()//default constructor
        {
            bookingID="";
            duration=0;
            customer=nullptr;
            hall=nullptr;
            status="Pending";
        }
        
        void setBookID(string id){bookingID=id;}
        void setDuration(int dur){duration=dur;}
        void setStatus(string s){status=s;}
        void setCustomer(Customer* c) { customer = c; }
        void setHall(EventHall* h) { hall = h; }
        void setInvoice(Invoice i){invoice=i;}
        void setDate(Date d) { date = d; }
        void setTime(Time t) { time = t; }

        string getBookID()const{return bookingID;}
        int getDuration()const {return duration;}
        string getStatus()const{return status;}
        Customer* getCustomer()const{return customer;}
        EventHall* getHall()const{return hall;}
        Invoice getInvoice()const{return invoice;}
        Date getDate()const{return date;}
        Time getTime()const{return time;}


        static void setBookingCount(int count)
       {
         ifstream in ("booking.txt");
         if (in)
         {
          string line;
          getline(in, line);
          int maxID=0;
          while(getline(in,line))
          {
            size_t pos=line.find(',');
            if(pos==string::npos)
               continue;
            string id= line.substr(0,pos);
            if(id.length()>1 && id[0]=='B')
            {
            try{
            int num=stoi(id.substr(1));
            if(num>maxID) maxID=num;
           }catch(...)
           {
            continue;
           }
          }
        }
           bookingCount=maxID;
         }else
         {
          bookingCount=0;
         }
        }

       static void saveBookingCounter()
       {
        ofstream out("booking.txt");
        out<<bookingCount;
       }
        string generateBookingID()
        {
          bookingCount++;
          string prefix="B";
          string id=to_string(bookingCount);
          while(id.length()<3)
          {
            id="0"+id;
          }
          return prefix +id;
        }

static void loadBooking(vector<Booking>& bookingList, vector<Customer>& customerList, vector<EventHall>& hallList)
{
    ifstream in("booking.txt");
    if (!in.is_open())
    {
        cout << "Failed to open booking.txt." << endl;
        bookingCount = 0;
        return;
    }

    string line;
    getline(in, line); // skip header

    //string ID, cName, hName, dateS, timeS, durS, amountS, payStatus, bookStatus;

    while (getline(in,line))
    {
        size_t pos1 = line.find(',');
        if (pos1 == string::npos) continue;
        string ID = line.substr(0, pos1);

        size_t pos2 = line.find(',', pos1 + 1);
        if (pos2 == string::npos) continue;
        string cName = line.substr(pos1 + 1, pos2 - pos1 - 1);

        size_t pos3 = line.find(',', pos2 + 1);
        if (pos3 == string::npos) continue;
        string hName = line.substr(pos2 + 1, pos3 - pos2 - 1);

        size_t pos4 = line.find(',', pos3 + 1);
        if (pos4 == string::npos) continue;
        string dateS = line.substr(pos3 + 1, pos4 - pos3 - 1);

        size_t pos5 = line.find(',', pos4 + 1);
        if (pos5 == string::npos) continue;
        string timeS = line.substr(pos4 + 1, pos5 - pos4 - 1);

        size_t pos6 = line.find(',', pos5 + 1);
        if (pos6 == string::npos) continue;
        string durS = line.substr(pos5 + 1, pos6 - pos5 - 1);

        size_t pos7 = line.find(',', pos6 + 1);
        if (pos7 == string::npos) continue;
        string amountS = line.substr(pos6 + 1, pos7 - pos6 - 1);

        size_t pos8 = line.find(',', pos7 + 1);
        if (pos8 == string::npos) continue;
        string payStatus = line.substr(pos7 + 1, pos8 - pos7 - 1);

        string bookStatus = line.substr(pos8 + 1);

        Booking b;
        b.setBookID(ID);
        b.setStatus(bookStatus);

        // Duration
        try 
        {
            b.setDuration(stoi(durS));
        } catch (...) 
        {
          cout << "Invalid duration for booking " << ID << endl;
          continue;
        }

        // Find customer
        bool foundC = false;
        for (Customer& c : customerList)
        {
          if (c.getName() == cName)
          {
            b.setCustomer(&c);
            foundC = true;
            break;
          }
        }
        if (!foundC)
        {
          cout << "Customer not found for booking " << ID << endl;
          continue;
        }

        // Find hall
        bool foundH = false;
        for (EventHall& h : hallList)
        {
            if (h.getHallName() == hName)  
            {
                b.setHall(&h);
                foundH = true;
                break;
            }
        }
        if (!foundH)
        {
            cout << "Hall not found for booking " << ID << endl;
            continue;
        }

        // Date
        try {
            string d = dateS.substr(0, 2);
            string m = dateS.substr(3, 2);
            string y = dateS.substr(6, 4);
            Date da;
            da.setDate(d, m, y);
            b.setDate(da);
        } catch (...) {
            cout << "Invalid date format in booking " << ID << endl;
            continue;
        }

        // Time
        try {
            string hr = timeS.substr(0, 2);
            string min = timeS.substr(3, 2);
            Time ti;
            ti.setTime(hr, min);
            b.setTime(ti);
        } catch (...) {
            cout << "Invalid time format in booking " << ID << endl;
            continue;
        }

        // Invoice
        try {
            Invoice inv;
            inv.generateInvoice(ID, stod(amountS));
            if (payStatus == "Paid")
                inv.setPaymentStatus(1);
            else if (payStatus == "Unsuccessful")
                inv.setPaymentStatus(-1);
            else
                inv.setPaymentStatus(0);
            b.setInvoice(inv);
        } catch (...) {
            cout << "Invalid amount in booking " << ID << endl;
            continue;
        }

        bookingList.push_back(b);
    }

    bookingCount = bookingList.size();
    in.close();
}


        double calcTotPrice()
        {
          return hall->getPrice()* duration;
        }
        void displayBooking () const
        {
          

          cout<<left<<setw(12)<<bookingID  
              <<setw(15)<<customer->getName()
              <<setw(22)<<hall->getHallName()
              <<setw(14)<<date.getDate()
              <<setw(10)<<time.getTime()
              <<setw(8)<<duration
              <<setw(10)<<invoice.getAmount()
              <<setw(20)<<invoice.getPaymentStatus()
              <<setw(20)<<status<<endl;
        }
        static void viewPastBookingHistory(const string& custName, const vector<Booking>& bookings, time_t currentTime) 
        {
         cout << "\n--- Booking History for " << custName << " ---"<<endl;
         cout << left << setw(12) << "BookingID"
              << setw(15) <<"Name"
              << setw(22) << "Hall"
              << setw(14) << "Date"
              << setw(10) << "Time"
              << setw(8)  << "Hours"
              << setw(10) << "Amount"
              << setw(20) << "Invoice"
              << setw(20) << "Status" << endl;

        bool found = false;
        for (const Booking& b : bookings) 
        {
         if ((b.getCustomer()->getName() == custName)&&(!b.isFutureBooking(currentTime))) 
         {
          b.displayBooking();
          found = true;
         }
        }
        if (!found) 
        {
        cout << "No past booking."<<endl;
        }
        }

        static void viewFutureBookingHistory(const string& custName, const vector<Booking>& bookings, time_t currentTime) 
        {
         cout << "\n--- Booking History for " << custName << " ---"<<endl;
         cout << left << setw(12) << "BookingID"
              << setw(15) <<"Name"
              << setw(22) << "Hall"
              << setw(14) << "Date"
              << setw(10) << "Time"
              << setw(8)  << "Hours"
              << setw(10) << "Amount"
              << setw(20) << "Invoice"
              << setw(20) << "Status" << endl;
        bool found = false;
        for (const Booking& b : bookings) 
        {
         if ((b.getCustomer()->getName() == custName) &&
            (b.isFutureBooking(currentTime)) )
         {
          b.displayBooking();
          found = true;
         }
        }
        if (!found) 
        {
        cout << "No upcoming booking."<<endl;
        }
        }

        bool isFutureBooking(time_t currentTime)const
        {
          tm *lt= localtime(&currentTime);
          int curY=1900 + lt->tm_year;
          int curM=1 + lt->tm_mon;
          int curD=lt->tm_mday;

          int bookY=stoi(date.getYear());
          int bookM=stoi(date.getMonth());
          int bookD=stoi(date.getDay());
    
          if (bookY > curY)
            return true;
          if ((bookY == curY)&&(bookM > curM ))
            return true;
          if ((bookY == curY)&&(bookM == curM )&&(bookD > curD))
            return true;
        return false;   
        }

        void createBooking(Customer* c, EventHall* h, int dur)
        {
           customer=c;
           hall=h;
           duration=dur;      
           double price=calcTotPrice();
           invoice.generateInvoice(bookingID, price);
           
           cout<<"\n-----Booking Details-----"<<endl
               <<"Booking ID: "<<bookingID<<endl 
               <<"Customer Name: "<<customer->getName()<<endl 
               <<"Hall: "<<hall->getHallName()<<endl 
               <<"Date: "<<date.getDate()<<endl 
               <<"Time: "<<time.getTime()<<endl 
               <<"Time: "<<duration<<"hour(s)"<<endl;

               invoice.printInvoice();
        }

void cancelRequest()
{
    if (status == "Confirmed")
    {
        status = "Pending Cancellation";
        cout << "Cancellation request sent to admin." << endl;
        cout << "Please wait for approval." << endl;
    }
    else if (status == "Pending Cancellation")
    {
        cout << "You have already requested cancellation. Please wait for admin approval." << endl;
    }
    else if (status == "Canceled")
    {
        cout << "This booking is already canceled." << endl;
    }
    else
    {
        cout << "This booking cannot be canceled in its current state." << endl;
    }
}

        void updateStatus()//manual update by admin(for booking)
        {
          if(status=="Canceled" || status=="Payment Failed"|| (status=="Confirmed" && invoice.getPaymentStatus()=="Paid"))
          {
            cout<<"This booking has already been marked as "<<status<<" and finalized."<<endl;
            return ;
          }
          cout<<"\n-----Updated Booking Status-----"<<endl;
          cout<<"Current status: "<<status<<endl;
          cout<<"Invoice status: "<<invoice.getPaymentStatus()<<endl;

          cout<<"Available action: "<<endl;
          cout<<"1. Mark as paid."<<endl;
          cout<<"2. Mark Payment Failed."<<endl;
          if(status=="Pending Cancellation" && invoice.getPaymentStatus()=="Paid")
          {
          cout<<"3. Approve Cancellation Request"<<endl;
          cout<<"4. Keep as Pending."<<endl;
          }
          cout<<"0.Keep as Pending(No Charge)"<<endl;
          cout<<"Your Choice:";
          int choice;
          cin>>choice;
          cin.ignore();

          switch (choice)
          {
           case 1:
           {
            if(invoice.getPaymentStatus()!="Paid")
            {
              invoice.setPaymentStatus(1);
              status="Confirmed";
              cout<<"Booking marked as Paid and Confirmed"<<endl;
            }else{
              cout<<"Invoice is already Paid."<<endl;
            }
            break;
           }

           case 2:
               if (invoice.getPaymentStatus() != "Paid")
                {
                    invoice.setPaymentStatus(-1);
                    status = "Payment Failed";
                    cout << "Marked as Payment Failed." << endl;
                } 
                else 
                {
                cout << "Cannot mark as failed or cancel. Payment already made." << endl;
                }
            break;
           case 3:
              {if(status == "Pending Cancellation")
              {
                status="Canceled.";
                invoice.setPaymentStatus(-1);
                cout<<"Cancellation approved. Booking canceled."<<endl;
              }else{
                cout<<"Invalid option."<<endl;
              }
              break;
            }
            case 4:
               if (status=="Pending Cancellation")
               {
                status="Confirmed";
                cout<<"Cancellation rejected. Booking kept as Confirmed.";
               }
               else{
                cout<<"Invalid option"<<endl;
               }
               break;
            case 0:
                cout<<"No change made to the bookings."<<endl;
                break;
            default:
                 cout<<"Invalid choice;";
                 break;
          }  
        }
void cancelBooking(time_t currentTime, vector<Booking>& bookingList, Customer* loginCust)
{
    string invoiceStatus = invoice.getPaymentStatus();

    if (status == "Canceled")
    {
        cout << "This booking is already canceled. Cannot cancel again." << endl;
        return;
    }

    if (invoiceStatus == "Pending")
    {
        status = "Canceled";
        invoice.setPaymentStatus(-1); // Unpaid cancel
        cout << "Booking canceled successfully (unpaid)." << endl;
    }
    else if (invoiceStatus == "Paid")
    {
        cancelRequest(); // will go to Pending Cancellation
    }
}

static void saveToFile(const vector<Booking>&bookingList)
{
  ofstream out("booking.txt");//this file can be append=update
  if(!out.is_open())
    {
      cout<<"Failed to open booking.txt"<<endl;
      return;
    }
  out << "BookingID,Customer,Hall,Date,Time,Hours,Amount,Invoice,Status" << endl;
 
  for(const Booking&b: bookingList)
  {
    out<<b.getBookID()<<","
      <<b.getCustomer()->getName()<<","
      <<b.getHall()->getHallName()<<","
      <<b.getDate().getDate()<<","
      <<b.getTime().getTime()<<","
      <<b.getDuration()<<","
      <<fixed<<setprecision(2)<<b.getInvoice().getAmount() <<","
      <<b.getInvoice().getPaymentStatus()<<","
      <<b.getStatus()<<endl;
  }
   out.close();
}
        
static bool checkAvailabilty(EventHall* e, Date d, Time t, const vector<Booking>& bookingList)
{
          Time start =t;
          Time end =t.addMi(60);
          Time bufferStart=start.addMi(-30);
          Time bufferEnd=end.addMi(30);

          for(const Booking &b : bookingList)
             {
               if(b.hall==e && b.date.getDate()== d.getDate())
                {
                  Time existStart = b.time;
                  Time existEnd = existStart.addMi(60);
                  Time existBufStart = existStart.addMi(-30);
                  Time existBufEnd = existEnd.addMi(30);

                  if (Time::checkOverlape(bufferStart, bufferEnd, existBufStart, existBufEnd)) {
                    cout << "Time Overlape. " << existStart.getTime()
                         << " - " << existEnd.getTime() << "have been booked"<<endl;
                    return false;// time conflict
                }
             }            
              } 
              return true; 
         } 
  ~Booking(){}     
};
int Booking::bookingCount = 0;
    
int main() 
{
    time_t currentTime= time(0);
    
    vector<Admin> adminList;
    vector<Customer> customerList;
    vector<EventHall> hallList;
    vector<Booking> bookingList;

    Admin ad;
    Customer cust;
    EventHall eh;
   

    ad.loadAdmin(adminList);
    cust.loadCustomer(customerList);
    eh.loadHall(hallList);
    Customer::setCustomerCount(customerList);
    Admin::setAdminCount (adminList);
    Booking::loadBooking(bookingList,customerList,hallList);

    Admin* loginAd = nullptr;
    Customer* loginCust = nullptr;

role:
    cout << "\n----- Event Hall Booking System -----" << endl;
    cout << "Please select your role: " << endl;
    cout << "1) Admin" << endl;
    cout << "2) Customer" << endl;
    cout << "3) New Customer"<<endl;
    cout << "Your choice: ";
    int role;
    cin >> role;
    cin.ignore(); // clear newline
    
    if(role==3)
    {
      cout << "\n----- Customer Registration -----"<<endl;
      string name, email, phone, password;

      cout << "Enter your name: ";
      getline(cin, name);
     
      do
      {
        cout << "Enter your email: ";
        getline(cin, email);
        if(!User::isValidEmail(email))
        {
          cout<<"Invalid email format. Must contain '@' and '.com' "<<endl;
        }
      }while(!User::isValidEmail(email));
    
      do{
        cout << "Enter your phone (01x-xxxxxxxxx): ";
        getline(cin, phone);
        if(!User::isValidPhoneNo(phone))
        {
          cout<<"Invalid phone number. Should be 10 or 11 digits."<<endl;
        }
        }while(!User::isValidPhoneNo(phone));
        
        do
        {
        cout << "Set your password (6 character): ";
        getline(cin, password);
        if(!User::isValidPasswordFormat(password))
        {
          cout<<"Password to short."<<endl;
        }
        }while(!User::isValidPasswordFormat(password));
        
        Customer newCust(name, email, phone, password);
        newCust.setID(newCust.getID());
        customerList.push_back(newCust);
        cust.saveCustomer(customerList);

        cout << "\nRegistration successful! Please login now."<<endl;
        goto role; 
        }

login:
    string name, password;
    bool login = false;

    while (!login)
{
    cout << "Username: ";
    getline(cin, name);
    cout << "Password: ";
    getline(cin, password);

    if (role == 1) 
    {
        for (Admin& a : adminList) 
        {
            if (a.getName() == name && a.getPassword() == password) 
            {
                loginAd = &a;
                login = true;
                break;
            }
        }

        if (!login) 
        {
            cout << "Login failed" << endl;
            cout << "1. Try Again" << endl;
            cout << "2. Forgot Password" << endl;
            cout << "3. Wrong Role" << endl;
            cout << "0. Exit" << endl;
            cout << "Your Choice: ";
            int choice;
            cin >> choice;
            cin.ignore();

            if (choice == 0) return 0;
            if (choice == 3) goto role;
            if (choice == 2) 
            {
                while (true)
                {
                    string email;
                    cout << "Enter email to reset (or 0 to cancel): ";
                    getline(cin, email);
                    if (email == "0") break;

                    bool found = false;
                    for (Admin& a : adminList) 
                    {
                        if (a.getName() == name && a.getEmail() == email) 
                        {
                            string newPass;
                            cout << "Verified. Enter new password: ";
                            getline(cin, newPass);
                            a.setPassword(newPass);
                            ad.saveAdmin(adminList);
                            cout << "Password updated successfully. Returning to login..." << endl;
                            goto login;
                        }
                    }
                    cout << "Email or name incorrect. Please try again." << endl;
                }
            }
        }
    }
    else if (role == 2) 
    {
        for (Customer& c : customerList) 
        {
            if (c.getName() == name && c.getPassword() == password) 
            {
                loginCust = &c;
                login = true;
                break;
            }
        }

        if (!login) 
        {
            cout << "Login failed." << endl;
            cout << "1. Try Again" << endl;
            cout << "2. Forgot Password." << endl;
            cout << "3. Wrong Role" << endl;
            cout << "0. Exit" << endl;
            cout << "Your Choice: ";
            int choice;
            cin >> choice;
            cin.ignore();

            if (choice == 0) return 0;
            if (choice == 3) goto role;
            if (choice == 2) 
            {
                while (true)
                {
                    string email;
                    cout << "Enter email to reset (or 0 to cancel): ";
                    getline(cin, email);
                    if (email == "0") break;

                    bool found = false;
                    for (Customer& c : customerList)
                    {
                        if (c.getEmail() == email && c.getName() == name)
                        {
                            string newPass;
                            cout << "Verified. Enter new password: ";
                            getline(cin, newPass);
                            c.setPassword(newPass);
                            cust.saveCustomer(customerList);
                            cout << "Password updated successfully. Returning to login..." << endl;
                            goto login;
                        }
                    }
                    cout << "Email or name incorrect. Please try again." << endl;
                }
            }
        }
    }
    else
    {
        cout << "Invalid role. Redirecting..." << endl;
        goto role;
    }
}

// Login success message
if (loginAd) 
{
    cout << "\nWelcome Admin: " << loginAd->getName() << endl;
}
else if (loginCust) 
{
    cout << "\nWelcome Customer: " << loginCust->getName() << endl;
}


    // Admin Dashboard
    if (role == 1 && loginAd != nullptr) 
    {
      
      int choice;
      do {
          loginAd->dispDashboard();
          cin >> choice;
          cin.ignore();

          switch (choice) {
              case 1:
                  loginAd->dispProfile();
                  break;
              case 2:
                  loginAd->updateProfile();
                  ad.saveAdmin(adminList);
                  break;
              case 3:
                  loginAd->setAcc();
                  ad.saveAdmin(adminList);
                  break;
              case 4: {
                  int ch4;
                   do {
                        cout << "\n--- Hall Management ---"<<endl;
                        cout <<"1. View All Halls"<<endl;
                        cout<<"2. Add New Hall"<<endl;
                        cout<<"3. Update Hall Info"<<endl;
                        cout<<"0. Back To Menu"<<endl;
                        cout<<"Your Choice: ";
                        cin >> ch4;
                        cin.ignore();

                        switch (ch4) 
                        {
                          case 1:
                              cout << left << setw(10) << "Hall ID"
                                   << setw(20) << "Hall Name"
                                   << setw(20) << "Capacity"
                                   << setw(10) << "Price(RM)" << endl;
                              for (EventHall& h : hallList)
                              {
                                h.displayHall();
                              }
                              break;
                          case 2: 
                              {
                                EventHall newHall;
                                newHall.setHallInfo();
                                newHall.setHallID(newHall.generateHallID());
                                hallList.push_back(newHall);
                                eh.saveHalls(hallList);

                                EventHall::setHallCount(hallList.size());
                                cout << "New hall added. ID: "<<newHall.getHallID()<<" "<<newHall.getHallName()<<endl;
                                break;
                              }
                          case 3: 
                              cout << left << setw(10) << "Hall ID"
                                   << setw(20) << "Hall Name"
                                   << setw(20) << "Capacity"
                                   << setw(10) << "Price(RM)" << endl;
                              {
                                for (EventHall& h : hallList)
                              {
                                h.displayHall();
                              }
                                string hallID;
                                bool found = false;
                                do 
                                {
                                 cout << "Enter Hall ID to update: ";
                                  getline(cin, hallID);
                                  for (EventHall& h : hallList) 
                                  {
                                    if (h.getHallID() == hallID) 
                                    {
                                     h.setHallInfo();
                                     eh.saveHalls(hallList);
                                     cout << "Hall updated."<<endl;;
                                     found = true;
                                     break;
                                    }
                                  }
                                  if (!found) 
                                  {
                                    cout << "Hall not found."<<endl;
                                  }
                                } while (!found);
                                break;
                            }
                          case 0:
                              cout << "Returning to Admin Menu..."<<endl;
                              break;
                          default:
                              cout << "Invalid choice."<<endl;
                              break;
                        }
                    } while (ch4 != 0);
                    break;
                }
                case 5:
                {
                 int ch5;
                  do
                  {
                    cout<<"\n-----Booking Management-----"<<endl;
                    cout<<"1. View All Booking"<<endl;
                    cout<<"2. Update Payment Status (Payment Confirmation/ Approve Cancellation)"<<endl;
                    cout<<"0. Back to Menu"<<endl;
                    cout<<"Your Choice:";
                    cin>>ch5;
                    cin.ignore();

                    switch(ch5)
                    {
                      case 1:
                        cout<<"\n-----Booking List-----"<<endl;
                        cout << left << setw(12) << "BookingID"
                             << setw(15) << "Customer"
                             << setw(22) << "Hall"
                             << setw(14) << "Date"
                             << setw(10) << "Time"
                             << setw(8)  << "Hours"
                             << setw(10) << "Amount"
                             << setw(20) << "Invoice"
                             << setw(20) << "Status" << endl;
                        for (Booking &b : bookingList)
                        {
                          b.displayBooking();
                        }
                        break;

                      case 2:
                        
                         while(true)
                         {             
                          cout<<"------Bookings Available for Update-----"<<endl;
                          cout<<left<<setw(12)<<"BookingID"
                              <<setw(15)<<"Customer"
                              <<setw(22)<<"Hall"
                              <<setw(14)<<"Date"
                              <<setw(10)<<"Time"
                              <<setw(8) <<"Hours"
                              <<setw(10)<<"Amount"
                              <<setw(18)<<"Status"
                              <<setw(18)<<"Invoice Status"<<endl;

                          for (Booking &b :bookingList)
                          {
                            if(b.getStatus() != "Canceled")
                            {
                              cout<<left<<setw(12)<<b.getBookID()
                                  <<setw(15)<<b.getCustomer()->getName()
                                  <<setw(22)<<b.getHall()->getHallName()
                                  <<setw(14)<<b.getDate().getDate()
                                  <<setw(10)<<b.getTime().getTime()
                                  <<setw(8) <<b.getDuration()
                                  <<setw(10)<<b.getInvoice().getAmount()
                                  <<setw(20)<<b.getStatus()
                                  <<setw(20)<<b.getInvoice().getPaymentStatus()<<endl;
                            }
                          }
                          string updateId;
                          cout<<"Enter the Booking ID to update status (or 0 return to menu):";
                          getline(cin,updateId);

                          if(updateId=="0")
                           {
                            cout<<"Update Canceled."<<endl;
                            break;
                           }
                          bool found=false;
                          for(Booking&b : bookingList)
                          {
                            if(b.getBookID()==updateId)
                            {
                              cout<<"-----Update Status for Booking ID: "<<b.getBookID()<<" -----"<<endl;
                              b.updateStatus();
                              Booking::saveToFile(bookingList);
                              cout<<"Status updated and saved."<<endl;
                              found=true;
                              cout<<"----- Updated Booking List -----"<<endl;
                              cout<<left<<setw(12)<<"BookingID"
                                  <<setw(15)<<"Customer"
                                  <<setw(22)<<"Hall"
                                  <<setw(14)<<"Date"
                                  <<setw(10)<<"Time"
                                  <<setw(8)<<"Hours"
                                  <<setw(10)<<"Amount"
                                  <<setw(20)<<"Status"
                                  <<setw(20)<<"Invoice Status"<<endl;

                                  for (Booking &b :bookingList)
                          {
                            if(b.getStatus() != "Canceled")
                            {
                              cout<<left<<setw(12)<<b.getBookID()
                                  <<setw(15)<<b.getCustomer()->getName()
                                  <<setw(22)<<b.getHall()->getHallName()
                                  <<setw(14)<<b.getDate().getDate()
                                  <<setw(10)<<b.getTime().getTime()
                                  <<setw(8) <<b.getDuration()
                                  <<setw(10)<<b.getInvoice().getAmount()
                                  <<setw(20)<<b.getStatus()
                                  <<setw(20)<<b.getInvoice().getPaymentStatus()<<endl;
                            }
                          }
                          break;
                        }
                    }
                          if(!found)
                          {
                            cout<<"Booking ID not found."<<endl;
                          }
                          cout << "\nContinue updating bookings? (y/n): ";
                          char cont;
                          cin >> cont;
                          cin.ignore();
                          if (cont == 'n' || cont == 'N')
                          {
                          cout << "Returning to admin menu..." << endl;
                          break;
                         }

                        }
                        break;
                      case 0:
                            cout<<"Returning to admin menu..."<<endl;
                            break;
                      default:
                            cout<<"Invalid choice"<<endl;
                            break;
                    }
                  } while (ch5!=0);  
                  break;                
                }
                case 6:
                   
                    {
                      string name, email, phone,password;
                      cout<<"\n-----Add New Admin-----"<<endl;
                      cout<<"Enter name: ";
                      getline(cin,name);
                      do{
                      cout << "Enter your email: ";
                      getline(cin, email);
                      if(!User::isValidEmail(email))
                      {
                       cout<<"Invalid email format. Must contain '@' and '.com' "<<endl;
                      }
                      }while(!User::isValidEmail(email));

                     do{
                      cout << "Enter your phone (01x-xxxxxxxxx): ";
                      getline(cin, phone);
                      if(!User::isValidPhoneNo(phone))
                       {
                        cout<<"Invalid phone number. Should be 10 or 11 digits."<<endl;
                       }
                       }while(!User::isValidPhoneNo(phone));

                     do{
                     cout << "Set your password (6 character): ";
                     getline(cin, password);
                     if(!User::isValidPasswordFormat(password))
                      {
                        cout<<"Password to short."<<endl;
                      }
                      }while(!User::isValidPasswordFormat(password));
                      Admin newAdmin(name,email,phone,password);
                      newAdmin.setID(newAdmin.getID());
                      adminList.push_back(newAdmin);
                      ad.saveAdmin(adminList);
                     

                      cout<<"New admin added successfully"<<endl;
                      break;

                    }
                case 0:
                    cout << "Logging out..."<<endl;
                    break;
                default:
                    cout << "Invalid input."<<endl;
                    break;
            }
        } while (choice != 0);
    }

    //customer dashboard 
    if((role==2) && (loginCust !=nullptr))
    {
      int choice;
      do
      {
        loginCust->dispDashboard();
        cin>>choice;
        cin.ignore();

        switch(choice)
        {
          case 1:
              loginCust->dispProfile();
              break;
          case 2:
              loginCust->updateProfile();
              cust.saveCustomer(customerList);
              break;
          case 3:
              cin.ignore();
              loginCust->setAcc();
              cust.saveCustomer(customerList);
              break;
          case 4:
              {
               bool cancel=false;
               EventHall*select=nullptr;
               Date d;
               Time t;
               int duration;
        h://rechoose the hall
              
            do{
                
                cout<<"\n-----Book A Hall-----"<<endl;
                cout<<"Available Hall:"<<endl;
                cout << left << setw(10) << "Hall ID"
                     << setw(20) << "Hall Name"
                     << setw(20) << "Capacity"
                     << setw(10) << "Price(RM)" << endl;
                for (EventHall& h: hallList)
                {
                  h.displayHall();
                }
                string hallID;
                cout<<"Please enter the hall ID of the event hall that you want to book:";
                getline(cin,hallID);

                select=nullptr;
                for(EventHall&h :hallList)
                {
                  if(h.getHallID()==hallID)
                  {
                  select=&h;
                  break;
                  }
                }
                if(! select)
                {
                  cout<<"Hall not found"<<endl;
                  cout<<"1. Re-enter Hall ID"<<endl;
                  cout<<"2. Cancel booking and return back to Customer Menu."<<endl;
                  
                  int ch;
                  cout<<"Your Choice :";
                  cin>>ch;
                  cin.ignore();
                  if(ch==2)
                  {
                    cancel=true;
                    break;
                  }
                }
              }while(!select);
              if(cancel) break;

           d://rechoose the date                              
                bool validDate=false;
                while(!validDate)
                {
                 try
                 {
                  d.enterDate();
                  if(!d.isFutureDate(currentTime))
                  {
                    throw invalid_argument("Date must not be in the past");
                  }
                  validDate=true;
                 }
                 catch(exception&e)
                 {
                  cout<<e.what()<<endl;
                  cout<<"1. Re-enter date."<<endl;
                  cout<<"2. Cancel booking and return to Customer Menu."<<endl;
                  cout<<"Your Choice: ";
       
                  int ch;
                  cin>>ch;
                  cin.ignore();
                  if(ch==2)
                  {
                    cancel=true;
                    break;
                  }
                }
              }
          
            if(cancel) break;
         t: //rechoose time                             
              bool validTime=false;
              while(!validTime)
              {
                try {                    
                     t.enterTime();
                     if(!t.isTimeInRange())
                     {
                      throw runtime_error("Booking time must between 10:00 AM to 23:30 PM");
                     }
                     cout<<"Enter duration (in hours): ";
                     cin>>duration;
                     cin.ignore();
                    
                     if(duration<=0)
                     {
                      throw runtime_error("Duration cannot be 0 or less.");
                     }

                     if(!t.exceedTime(duration))
                     {
                      throw runtime_error("Booking time must and before 23:30.");
                     }
                  if(!Booking::checkAvailabilty(select,d,t,bookingList))
                  {
                    cout<<"This time slot is already booked or overlape with an existing booking"<<endl;
                    cout<<"1. Choose another time"<<endl;
                    cout<<"2. Choose another hall"<<endl;
                    cout<<"3. Choose another date"<<endl;
                    cout<<"4. Cancel booking "<<endl;
              
                    int ch;
                    cout<<"Your Choice: ";
                    cin>>ch;
                    cin.ignore();
                    if(ch==1)
                    {
                      goto t;
                    }
                    else if(ch==2)
                    {
                      goto h;
                    }
                    else if(ch==3)
                    {
                      goto d;
                    }
                    else {
                      cancel=true;
                      cout<<"Booking cancel. Returing to menu"<<endl;
                      break;
                    }
                  }
                  validTime=true;
                }
                catch(exception&e)
                { 
                     cout<<e.what()<<endl;
                     cout<<"1. Re-enter time"<<endl;
                     cout<<"2. Cancel booking and return to Customer Menu."<<endl;
                     cout<<"Your Choice: ";
       
                     int ch;
                     cin>>ch;
                     cin.ignore();
                     if(ch==2)
                      {
                        cancel=true;
                        break;
                      }
                 }
              }
                

                
                if(!cancel)
                {
                  
                Booking newB;
                newB.setCustomer(loginCust);
                newB.setHall(select);
                newB.setDate(d);
                newB.setTime(t);
                newB.setDuration(duration);
                newB.setBookID(newB.generateBookingID());
                newB.createBooking(loginCust,select,duration);

                bookingList.push_back(newB);
                Booking::saveToFile(bookingList);
                cout<<"Booking successful ! "<<endl;
                }else
                {
                  cout<<"Booking Cancel. Returning to menu."<<endl;
                }    
                break; 
              }
          case 5:
              int ch5;
              do
              {
                cout<<"\n-----View Bookings-----"<<endl;
                cout<<"1. View Upcoming Bookings"<<endl;
                cout<<"2. View Past Bookings"<<endl;
                cout<<"0.Back"<<endl;
                cout<<"Your Choice:";
                cin>>ch5;
                cin.ignore();

                switch (ch5)
                {
                case 1:
                  Booking::viewFutureBookingHistory(loginCust->getName(),bookingList,currentTime);
                  break;
                case 2:
                  Booking::viewPastBookingHistory(loginCust->getName(),bookingList,currentTime);
                  break;
                case 0:
                  cout<<"Back to Customer Menu"<<endl;
                  break;
                default:
                  cout<<"Invalid choice."  <<endl;
                  break;
                }
              } while (ch5 !=0);
              break;

          case 6:
             {
              while (true)
             {
            cout << "\n-----Cancel Booking-----" << endl;
            cout << "Your upcoming bookings:" << endl;
            cout << left << setw(12) << "BookingID"
                 << setw(15) << "Name"
                 << setw(22) << "Hall"
                 << setw(14) << "Date"
                 << setw(10) << "Time"
                 << setw(8)  << "Hours"
                 << setw(10) << "Amount"
                 << setw(20) << "Invoice"
                 << setw(20) << "Status" << endl;

            bool found = false;
            for (Booking& b : bookingList)
            {
                if (b.getCustomer()->getName() == loginCust->getName() && b.isFutureBooking(currentTime))
                {
                    b.displayBooking();
                    found = true;
                }
            }

            if (!found)
            {
                cout << "No upcoming bookings found." << endl;
                break;
            }

            string bookId;
            cout << "Enter Booking ID to cancel (or 0 to exit): ";
            getline(cin, bookId);
            if (bookId == "0")
            {
                cout << "Cancellation request cancelled by user.\n";
                break;
            }

            bool match = false;
            for (Booking& b : bookingList)
            {
                if (b.getCustomer()->getName() == loginCust->getName() &&
                    b.getBookID() == bookId &&
                    b.isFutureBooking(currentTime))
                {
                    match = true;

                    if (!(b.getStatus()== "Pending" || (b.getStatus()=="Confirmed" && b.getInvoice().getPaymentStatus()=="Paid")))
                    {
                        int subChoice;
                        do {
                            cout << "This booking is already canceled. Cannot cancel again." << endl;
                            cout << "1. Re-enter Booking ID" << endl;
                            cout << "2. Return to Customer Menu" << endl;
                            cout << "Your choice: ";
                            cin >> subChoice;
                            cin.ignore();
                        } while (subChoice != 1 && subChoice != 2);

                        if (subChoice == 1)
                            continue;
                        else
                            break; // return to menu
                    }

                    b.cancelBooking(currentTime, bookingList, loginCust);
                    Booking::saveToFile(bookingList);
                    break;
                }
            }

            if (!match)
            {
                int subChoice;
                do {
                    cout << "Booking ID not found or not cancellable." << endl;
                    cout << "1. Re-enter Booking ID" << endl;
                    cout << "2. Return to Customer Menu" << endl;
                    cout << "Your choice: ";
                    cin >> subChoice;
                    cin.ignore();
                } while (subChoice != 1 && subChoice != 2);

                if (subChoice == 1)
                    continue;
                else
                    break;
             }  
           
        }
        break;
      }



          case 0:
             cout<<"Logging out..."<<endl;
             break;
          default:
             cout<<"Invalid choice."<<endl;
                          
        }
      } while (choice !=0);
    }
    system("pause");
    return 0;
}